import logo from './logo.svg';
import Header from './components/Header'
import Home from './components/home'
import Services from './components/services'
import Pricing from './components/Pricing'
import AboutUs from './components/about_us'
import Contact from './components/contact'
import Footer from './components/footer'
import Inscription from './components/inscription';
import { BrowserRouter as Router,Switch, Route } from "react-router-dom";
import React from 'react';
import './App.css';

function App() {
  return (
    <Router>
        <Switch>
          <Route path="/test" component={InscriptionPage}/>
          <Route path="/" exact component={HomePage}/>
        </Switch>
    </Router>
    );
}

const HomePage =()=>{
  return(
    <div className="app">
      <Header />
      <Home />
      <Services />
      <Pricing />
      <Contact />
      <Footer />
    </div>
  );
}

const InscriptionPage =()=>{
  return(
    <div className="app">
      <Header />
      <Inscription />
      <Footer />
    </div>
  );
}

export default App;
