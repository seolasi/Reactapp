import '../App.css';
import Imag from '../assets/img/logo_home_main.png';
import SearchIcon from '@mui/icons-material/Search';
function Footer(){
   return(
       <div className="flx_footer className_gradiant headerul">
           <div className="width_33_spcl42" >
           </div>
           <div className="width_66 width_33 header_center_div">
               <ul className='flx_xl_menu'>
                   <li>
                       Home
                   </li>
                   <li>
                       à propos
                   </li>
                   <li>
                       contact
                   </li>
               </ul>
           </div>
       </div>
   )
}
export default Footer;