 import '../App.css';
 import Imag from '../assets/img/logo_home_main.png';
 
import Contact from './Header'
 //import SearchIcon from '@mui/icons-material/Search';
 import {
    Link
  } from "react-router-dom";
 function Header(){
    return(
        <div className="flx-header className_gradiant headerul">
            <div className="width_33_spcl42" >
                   <Link to="test" className='flx_join_us_a' >
                        <span>Joindre Nous</span>
                    </Link>
            <img src={Imag}  className="log_top_bar"/>
            </div>
            <div className="width_66 width_33 header_center_div">
                <ul className='flx_xl_menu'>
                    <li>
                        Home
                    </li>
                    <li>
                        à propos
                    </li>
                    <li>
                        contact
                    </li>
                </ul>
            </div>
        </div>
    )
}
export default Header;