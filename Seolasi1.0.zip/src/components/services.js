import Imag from '../assets/img/logo_home_main.png';
import About_us from '../assets/img/about-us.jpg';

import Joinus from '../assets/img/social-media-marketing-digital-marketing-png-favpng-BaG3Fj36Bk5iPCeMcZVB4gjJx.jpg';

function Services(){
    return(
    <div className='flx-container'>
        <div className="flx-home flx_about_us">
            <h2 className="flx_about_us_h2">Nos services</h2> 
            <div className='flx_services_holder'>
                    <div className='flx_srvices_card'>
                        <div className='container'>     
                            <div className='container1'>
                                <h3>Visibilité Digital</h3>
                                <p>
                                    Création, modération des profiles sur toutes les plateformes nécessaires, SEO (Search Engine
                                    Optimisation) et SEA (Search Engine Advertising) :
                                </p>
                                <p> renforcer les relations publiques
                                    professionnellement ciblé pour garantir la présence organique avec classement avancé sur tous les
                                    moteurs des recherches connus (Recherche et mise à jour des Mot Clés / Hashtags celons la niche,
                                    Ajouter Lyrics, Captions etc. …)
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className='flx_srvices_card'>
                        <div className='container'>     
                            <div className='container1'>
                                <h3>Plan publicitaire</h3>
                                <p>Sponsoring + Bande-annonce des chansons</p>
                                <p>
                                    Aider les artistes à atteindre les critères de monétisation et l’obtention Badges Artiste
                                    Vérifier
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className='flx_srvices_card'>
                        <div className='container'>     
                            <div className='container1'>
                                <h3>Gestion des réseaux sociaux</h3>
                                <p>Sponsoring + Bande-annonce des chansons</p>
                                <p>
                                    Community Management, Analyse et Rapports mensuel
                                </p>
                                <ul>
                                    <li>
                                        Création et mise à jour des pages Wikipédia
                                    </li>
                                    <li>
                                        Planification des Quiz et jeux promotionnelles récompensé
                                    </li>
                                    <li>
                                        Organisation des défis et connexion de partenariat entre nos Artistes clients
                                    </li>
                                    <li>
                                    Conclure des actes de partenariat et collaboration avec des grandes marque internationaux
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className='flx_srvices_card'>
                        <div className='container'>     
                            <div className='container1'>
                                <h3>Design Graphique :</h3>
                                <p>Sponsoring + Bande-annonce des chansons</p>
                                <p>
                                Images des publications, affiches des événements professionnels, photos de couverture, Miniatures
des vidéos, etc.…
                                </p>
                                <ul>
                                    <li>
                                    Des portraits, caricaturisation a la main et animation 3D
                                    </li>
                                    <li>
                                    Création de panel GoogleCréation de panel Google
                                    </li>
                                    <li>
                                    Bénéficier des avantages spéciaux de la part de la société de distribution musical mondial
                                    </li>
                                    <li>
                                    Bénéficier des avantages spéciaux de la part de la société de distribution musical mondial
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    )
}
export default Services;