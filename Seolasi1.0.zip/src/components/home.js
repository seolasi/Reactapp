import Imag from '../assets/img/logo_home_main.png';
import Equilizer from '../assets/img/equilizer-home.png';
function Home(){
    return(
        <div className="flx-home">
        <div className="flx-home">
            <img src={Imag}  className="logo_home_main animate2_img"/>
        </div>
        <div className="flx-home">
            <img src={Equilizer}  className="logo_home_main"/>
        </div>
        </div>
    )
}
export default Home;