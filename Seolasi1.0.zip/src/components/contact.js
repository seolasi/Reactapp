import Imag from '../assets/img/logo_home_main.png';
import About_us from '../assets/img/about-us.jpg';

import Joinus from '../assets/img/social-media-marketing-digital-marketing-png-favpng-BaG3Fj36Bk5iPCeMcZVB4gjJx.jpg';

function Contact(){
    return(
    <div className='flx-container'>
        <div className="flx-home flx_about_us">
            <h2 className="flx_about_us_h2">Contactez-Nous</h2> 
           <form className='flx_contact_form'>
            <h3>Envoyer une message pour plus d'information</h3>
                    <input type="text" placeholder='Nom' />
                    <input type="mail" placeholder='mail' />
            <textarea rows='6' />
            <input type='submit' value='Envoyer' />
           </form>
        </div>
    </div>
    )
}
export default Contact;