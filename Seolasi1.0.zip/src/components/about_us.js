import Imag from '../assets/img/logo_home_main.png';
import About_us from '../assets/img/about-us.jpg';

import Joinus from '../assets/img/social-media-marketing-digital-marketing-png-favpng-BaG3Fj36Bk5iPCeMcZVB4gjJx.jpg';

function AboutUs(){
    return(
    <div className='flx-container'>
        <div className="flx-home flx_about_us">
            <h2 className="flx_about_us_h2">Qui sommes nous ?</h2> 
            <div className='flx_about_us_img_holder'>
                <img src={About_us} />
                <p className="flx_p_about_us1">
                Notre équipe est spécialisée dans le marketing et management de musique digital. Nous avons
                acquis l’expérience nécessaire dans ce domaine pour booster les efforts de nos différents artistes et
                leurs fournir plus de sucées.
                </p>
                <p className="flx_p_about_us1">
                    Notre équipe, a toutes les cartes en main pour assister
                    les artistes dans leurs développements.
                </p>
                <p className="flx_p_about_us1">
                Nous mettons à la disposition de nos stars une équipe jeune, dynamique, expérimentée et
                professionnelle, pour les guider dans l’élaboration de leurs stratégies marketing et création de
                propaganda et buzz.
                </p>
            </div>
        </div>
    </div>
    )
}
export default AboutUs;