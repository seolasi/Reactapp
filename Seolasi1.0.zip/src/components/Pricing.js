import Imag from '../assets/img/logo_home_main.png';
import About_us from '../assets/img/about-us.jpg';

import { BiCheck } from "react-icons/bi";
import {BiBlock} from "react-icons/bi";

const pricing_data= [
        {
            id: 0,
            title : 'Gestion des plateformes / réseaux sociaux',
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 1,
            title : `Aider les artistes à atteindre les critères de
                    monétisation et l’obtention Badges Artiste
                    Vérifier`,
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 2,
            title : `Sécurisation et résolution des conflits sur
                    toutes les plateformes`,
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 3,
            title : `Plan publicitaire`,
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 4,
            title : `Graphique design`,
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 5,
            title : `(Recherche et mise à jour des Mot Clés /
            Hashtags celons la niche, Ajouter Lyrics,
            Captions etc. …)`,
            active_silver : 1,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 6,
            title : `Publication des Quiz et jeux promotionnelles
            récompensé`,
            active_silver : 0,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 7,
            title : `Elaboration des stratégies marketing`,
            active_silver : 0,
            active_gold : 1,
            active_patinium : 1,
        },
        {
            id: 8,
            title : `Des portraits, caricaturisation a la main et
            animation 3D`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 9,
            title : `Gestion des événements virtuel et réel`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 10,
            title : `Création de panel Google`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 11,
            title : `Bénéficier des avantages spéciaux de la part
            de la société de distribution musical mondial
            Seolasi.com`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 12,
            title : `Création et mise à jour des pages Wikipédia`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 13,
            title : `Conclure des actes de partenariat et
            collaboration avec des grandes marques
            internationales`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 14,
            title : `Support 24/24 7/7`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
        {
            id: 15,
            title : `Organisation des défis et connexion de
            partenariat entre nos Artistes clients`,
            active_silver : 0,
            active_gold : 0,
            active_patinium : 1,
        },
    ];


    const listItems = pricing_data.map((item) =>{
      let icon_silver =<BiCheck />;
      let icon_gold =<BiCheck />;
      if(item.active_silver === 0){
        icon_silver =<BiBlock className='color_red'/>;
      }
      if(item.active_gold === 0){
        icon_gold =<BiBlock className='color_red'/>;
      }
      return(
        <div className='flx_pricing_holder row' key={item.id}>
                <div className="flx_price_card width_33">
                    <div className="max_width_100">
                        <h3 className="h3_silver  margin_0 font_weight_400_14">
                            {icon_silver}
                            <span>{item.title}</span>
                        </h3>
                    </div>
                </div>
                <div className="flx_price_card width_33">
                    <div className="max_width_100">
                        
                        <h3 className="h3_gold  margin_0 font_weight_400_14">
                            {icon_gold}
                            <span>{item.title}</span>
                        </h3>
                    </div>

                </div>
                <div className="flx_price_card width_33 ">
                    <div className="max_width_100">
                        
                        <h3 className="h3_platinium  margin_0 font_weight_400_14">
                            <BiCheck />
                            <span>{item.title}</span>
                        </h3>
                    </div>
                </div>
                </div>)
                }
    );
    
    console.log(pricing_data);
    
function Pricing(){
   
    return(
    <div className='flx-container'>
        <div className="flx-home flx_about_us">
            <h2 className="flx_about_us_h2">Pricing</h2> 
            <div className='flx_pricing_holder row'>
                <div className="flx_price_card width_33">
                    <div className="max_width_100">
                        <h3 className="h3_silver">Silver</h3>
                    </div>
                </div>
                <div className="flx_price_card width_33">
                    <div className="max_width_100">
                        <h3 className="h3_gold">Gold</h3>
                    </div>

                </div>
                <div className="flx_price_card width_33">
                    <div className="max_width_100">
                        <h3 className="h3_platinium">Platinium</h3>
                    </div>
                </div>
            </div>
                    {listItems}
        </div>
    </div>
    )
}
export default Pricing;